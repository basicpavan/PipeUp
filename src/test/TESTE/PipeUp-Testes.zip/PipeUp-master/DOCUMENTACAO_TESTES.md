
# Documentação de Casos de Teste – Projeto PipeUp

## Objetivo
Garantir que as funcionalidades principais do sistema PipeUp funcionem corretamente.

---

# Casos de Teste

## CT-001 – Carregar Dashboard sem filtro
### Objetivo
Verificar se o dashboard carrega corretamente sem filtro de tarefas.

### Entrada
Acesso ao endpoint `/dashboard` sem parâmetro filtro.

### Resultado Esperado
O sistema deve retornar a view `dashboard` e listar todas as tarefas.

### Status
Passou

---

## CT-002 – Filtrar tarefas
### Objetivo
Validar a busca de tarefas pela descrição.

### Entrada
Filtro = "teste"

### Resultado Esperado
Executar método `findByDescricaoContaining`.

### Status
Passou

---

## CT-003 – Criar espaço válido
### Objetivo
Garantir criação de espaço quando empresa existe.

### Entrada
Nome = "Financeiro"
EmpresaId = 1

### Resultado Esperado
Espaço salvo com sucesso.

### Status
Passou

---

## CT-004 – Não criar espaço sem empresa
### Objetivo
Impedir criação de espaço inválido.

### Entrada
Empresa inexistente

### Resultado Esperado
Não salvar espaço.

### Status
Passou

---

## CT-005 – Criar empresa
### Objetivo
Validar cadastro de empresa.

### Entrada
Nome = "PipeUp"

### Resultado Esperado
Empresa salva no banco.

### Status
Passou

---

## CT-006 – Excluir espaço
### Objetivo
Validar exclusão de espaço.

### Entrada
EspacoId = 1

### Resultado Esperado
Espaço removido.

### Status
Passou

---

## CT-007 – Excluir empresa
### Objetivo
Validar exclusão de empresa.

### Entrada
EmpresaId = 1

### Resultado Esperado
Empresa removida.

### Status
Passou

---

## CT-008 – Teste model Empresa
### Objetivo
Validar getters e setters da entidade Empresa.

### Resultado Esperado
Dados persistidos corretamente no objeto.

### Status
Passou

---

## CT-009 – Teste model Espaco
### Objetivo
Validar entidade Espaco.

### Resultado Esperado
Dados atribuídos corretamente.

### Status
Passou

---

## CT-010 – Teste model Tarefa
### Objetivo
Validar entidade Tarefa.

### Resultado Esperado
Dados atribuídos corretamente.

### Status
Passou

---

# Tecnologias utilizadas
- JUnit 5
- Mockito
- Spring Boot Test
- IntelliJ IDEA

# Cobertura realizada
- Controller
- Models
- Fluxos de criação
- Fluxos de exclusão
- Filtros
- Validação de regras básicas
