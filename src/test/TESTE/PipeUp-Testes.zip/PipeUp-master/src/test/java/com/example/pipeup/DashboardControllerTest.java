
package com.example.pipeup;

import com.example.pipeup.controller.DashboardController;
import com.example.pipeup.model.Empresa;
import com.example.pipeup.model.Espaco;
import com.example.pipeup.repository.EmpresaRepository;
import com.example.pipeup.repository.EspacoRepository;
import com.example.pipeup.repository.TarefaRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.ui.ConcurrentModel;
import org.springframework.ui.Model;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class DashboardControllerTest {

    private final EmpresaRepository empresaRepository = mock(EmpresaRepository.class);
    private final EspacoRepository espacoRepository = mock(EspacoRepository.class);
    private final TarefaRepository tarefaRepository = mock(TarefaRepository.class);

    @Test
    void deveCarregarDashboardSemFiltro() {
        DashboardController controller = new DashboardController();

        inject(controller);

        Model model = new ConcurrentModel();

        String view = controller.dashboard(model, null);

        assertEquals("dashboard", view);
        verify(tarefaRepository, times(1)).findAll();
    }

    @Test
    void deveFiltrarTarefasPorDescricao() {
        DashboardController controller = new DashboardController();

        inject(controller);

        Model model = new ConcurrentModel();

        String view = controller.dashboard(model, "teste");

        assertEquals("dashboard", view);
        verify(tarefaRepository, times(1)).findByDescricaoContaining("teste");
    }

    @Test
    void deveCriarEspacoComDadosValidos() {
        DashboardController controller = new DashboardController();

        inject(controller);

        Empresa empresa = new Empresa();
        empresa.setId(1);

        when(empresaRepository.findById(1)).thenReturn(Optional.of(empresa));

        String retorno = controller.criarEspaco("Financeiro", 1);

        assertEquals("redirect:/dashboard", retorno);
        verify(espacoRepository, times(1)).save(any(Espaco.class));
    }

    @Test
    void naoDeveCriarEspacoSemEmpresa() {
        DashboardController controller = new DashboardController();

        inject(controller);

        when(empresaRepository.findById(1)).thenReturn(Optional.empty());

        String retorno = controller.criarEspaco("Financeiro", 1);

        assertEquals("redirect:/dashboard", retorno);
        verify(espacoRepository, never()).save(any(Espaco.class));
    }

    @Test
    void deveCriarEmpresa() {
        DashboardController controller = new DashboardController();

        inject(controller);

        String retorno = controller.criarEmpresa("PipeUp");

        assertEquals("redirect:/dashboard", retorno);
        verify(empresaRepository, times(1)).save(any(Empresa.class));
    }

    @Test
    void deveExcluirEspaco() {
        DashboardController controller = new DashboardController();

        inject(controller);

        String retorno = controller.excluirEspaco(1);

        assertEquals("redirect:/dashboard", retorno);
        verify(espacoRepository, times(1)).deleteById(1);
    }

    @Test
    void deveExcluirEmpresa() {
        DashboardController controller = new DashboardController();

        inject(controller);

        String retorno = controller.excluirEmpresa(1);

        assertEquals("redirect:/dashboard", retorno);
        verify(empresaRepository, times(1)).deleteById(1);
    }

    private void inject(DashboardController controller) {
        try {
            var empresaField = DashboardController.class.getDeclaredField("empresaRepository");
            empresaField.setAccessible(true);
            empresaField.set(controller, empresaRepository);

            var espacoField = DashboardController.class.getDeclaredField("espacoRepository");
            espacoField.setAccessible(true);
            espacoField.set(controller, espacoRepository);

            var tarefaField = DashboardController.class.getDeclaredField("tarefaRepository");
            tarefaField.setAccessible(true);
            tarefaField.set(controller, tarefaRepository);

        } catch (Exception e) {
            fail(e.getMessage());
        }
    }
}
