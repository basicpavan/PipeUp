
package com.example.pipeup;

import com.example.pipeup.model.Espaco;
import com.example.pipeup.model.Tarefa;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class TarefaTest {

    @Test
    void deveSetarDadosTarefa() {
        Espaco espaco = new Espaco();
        espaco.setNome("Desenvolvimento");

        Tarefa tarefa = new Tarefa();

        tarefa.setId(1);
        tarefa.setDescricao("Criar testes");
        tarefa.setProgresso(75f);
        tarefa.setData(LocalDate.now());
        tarefa.setEspaco(espaco);

        assertEquals(1, tarefa.getId());
        assertEquals("Criar testes", tarefa.getDescricao());
        assertEquals(75f, tarefa.getProgresso());
        assertNotNull(tarefa.getData());
        assertEquals("Desenvolvimento", tarefa.getEspaco().getNome());
    }
}
