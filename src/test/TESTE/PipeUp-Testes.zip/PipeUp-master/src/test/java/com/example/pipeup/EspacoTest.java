
package com.example.pipeup;

import com.example.pipeup.model.Empresa;
import com.example.pipeup.model.Espaco;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

public class EspacoTest {

    @Test
    void deveSetarDadosEspaco() {
        Empresa empresa = new Empresa();
        empresa.setNome("Empresa Teste");

        Espaco espaco = new Espaco();
        espaco.setId(1);
        espaco.setNome("TI");
        espaco.setEmpresa(empresa);
        espaco.setDataCriacao(LocalDateTime.now());

        assertEquals(1, espaco.getId());
        assertEquals("TI", espaco.getNome());
        assertEquals("Empresa Teste", espaco.getEmpresa().getNome());
        assertNotNull(espaco.getDataCriacao());
    }
}
