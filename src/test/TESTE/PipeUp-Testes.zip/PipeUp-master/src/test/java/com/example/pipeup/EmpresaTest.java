
package com.example.pipeup;

import com.example.pipeup.model.Empresa;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class EmpresaTest {

    @Test
    void deveSetarDadosEmpresa() {
        Empresa empresa = new Empresa();

        empresa.setId(1);
        empresa.setNome("PipeUp");

        assertEquals(1, empresa.getId());
        assertEquals("PipeUp", empresa.getNome());
    }
}
